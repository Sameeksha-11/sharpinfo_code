package _04_05.before;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {

        List<String> fruit = Arrays.asList("apple", "pineapple", "banana", "pear", "strawberry");
        processWithStreams(fruit);
        List<String> capitalisedFruit = processWithoutStreams(fruit);
        System.out.println(capitalisedFruit);
    }

    static List<String> processWithoutStreams(List<String> fruit) {
        List<String> capitalisedFruit = new ArrayList<>();
        for (String item : fruit) {
            item = item.toUpperCase();
            if(item.startsWith("P"))
            {
                capitalisedFruit.add(item);
            }
        }
        Collections.sort(capitalisedFruit);
        return capitalisedFruit;
    }

    static void processWithStreams(List<String> fruit)
    {

        System.out.println(fruit.stream()
                .map(String::toUpperCase)
                .filter(item->item.startsWith("P"))
                .sorted()
                .collect(Collectors.joining()));

    }
}
