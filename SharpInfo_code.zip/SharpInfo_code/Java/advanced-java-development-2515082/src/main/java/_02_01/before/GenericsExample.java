package _02_01.before;


public class GenericsExample {

    public static void main(String[] args) {
    //Assignment-2
        //Q1
        System.out.println("for loop");
        for (int i = 0; i <= 10; i++) {
            System.out.print(i + " ");
        }
        System.out.println("\nWhile loop");
        int j = 0;
        while (j <= 10) {
            System.out.print(j + " ");
            j++;
        }
        System.out.println("\ndo-while loop");
        int k = 0;
        do {
            System.out.print(k + " ");
            k++;
        } while (k <= 10);
        System.out.println("\nforeach loop");
        int[] numbers = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int num : numbers) {
            System.out.print(num + " ");
        }

        //Q2
        int num = 10;
        if (num % 2 == 0) {
            System.out.println(num + " is even");
        } else {
            System.out.println(num + " is odd");
        }

        //Q3
        int day = 2;
        String dayName;
        switch (day) {
            case 1:
                dayName = "Sunday";
                break;
            case 2:
                dayName = "Monday";
                break;
            // Add cases for other days as needed
            default:
                dayName = "Invalid day";
        }
        System.out.println("Day is " + dayName);

        //Q4
        int a = 10;
        int b = 5;
        System.out.println("Addition: " + (a + b));
        System.out.println("Subtraction: " + (a - b));
        System.out.println("Multiplication: " + (a * b));
        System.out.println("Division: " + (a / b));
        System.out.println("Modulus: " + (a % b));

        //Q5
        int x = 5;
        int y = 3;
        System.out.println("Bitwise AND: " + (x & y));
        System.out.println("Bitwise OR: " + (x | y));
        System.out.println("Bitwise XOR: " + (x ^ y));
        System.out.println("Bitwise Complement of x: " + (~x));
        System.out.println("Left Shift of x by 1: " + (x << 1));
        System.out.println("Right Shift of x by 1: " + (x >> 1));

        //Q6
        String result = (num % 2 == 0) ? "even" : "odd";
        System.out.println(num + " is " + result);

        //Q7
        for (int i = 50; i <= 60; i++) {
            if (i == 54 || i == 56) {
                continue;
            }
            if (i % 2 == 0) {
                System.out.print(i + " ");
            }
        }

        //Q8
        int number = 12321; // Example number
        String originalNumber = String.valueOf(number);
        StringBuilder str = new StringBuilder(originalNumber).reverse();
        String reversedNumber = str.toString();
        if (originalNumber.equals(reversedNumber)) {
            System.out.println("\nPalindrome");
        } else {
            System.out.println("\nNot Palindrome");
        }}
}
