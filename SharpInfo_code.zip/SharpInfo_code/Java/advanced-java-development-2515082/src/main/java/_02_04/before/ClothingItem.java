package _02_04.before;

public abstract class ClothingItem {

    abstract int getPrice();

    abstract String getName();

}
