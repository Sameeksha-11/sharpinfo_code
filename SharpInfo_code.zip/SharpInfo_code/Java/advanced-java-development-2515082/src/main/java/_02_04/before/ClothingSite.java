package _02_04.before;

import java.util.ArrayList;
import java.util.List;

public class ClothingSite {
    public static void main(String[] args) {
        JacketItem jacketItem = new JacketItem();
        ShirtItem shirtItem = new ShirtItem();
        //checkoutItem(jacketItem);
        List<ClothingItem> arr = new ArrayList<>();
        arr.add(jacketItem);
        arr.add(shirtItem);
        listCheckout(arr);

    }

    static void checkoutItem(ClothingItem item) {
        System.out.println("Item purchased: " + item.getName() + ", price: " + item.getPrice());
    }

    static void listCheckout(List<ClothingItem> itmes)
    {
        for(ClothingItem i : itmes)
        checkoutItem(i);
    }


}
