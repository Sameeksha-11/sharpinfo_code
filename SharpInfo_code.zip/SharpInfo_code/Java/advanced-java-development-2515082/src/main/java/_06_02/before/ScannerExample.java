package _06_02.before;

import java.util.Scanner;

public class ScannerExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Name: ");
        scanner.nextLine();
        System.out.print("Enter age: ");
        scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter occupation:");
        String oc = scanner.nextLine();
        System.out.println(oc);


    }

}
