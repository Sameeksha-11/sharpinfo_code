package Demo2;
import Demo1.GenericFile;


public class Gen2 {

    public static void main(String[] args) {
        GenericFile obj = new GenericFile();
        obj.Greetings();

    }

}
