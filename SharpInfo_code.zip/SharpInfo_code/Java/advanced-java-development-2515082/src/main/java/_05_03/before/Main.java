package _05_03.before;


public class Main {

    public static void main(String[] args) {

        Thread threadOne = new Thread(new ThreadExample());
        Thread threadTwo = new Thread(()-> System.out.println("Lambda Runnable Thread"));

        threadOne.setName("First thread");
        threadTwo.setName("Second thread");

        threadOne.start();
        threadTwo.start();
    }

}
