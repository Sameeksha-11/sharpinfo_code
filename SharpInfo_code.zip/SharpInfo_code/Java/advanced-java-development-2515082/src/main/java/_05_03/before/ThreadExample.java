package _05_03.before;

public class ThreadExample implements Runnable {


    @Override
    public void run() {
        System.out.println("Hello World from Runnable");
    }


}
