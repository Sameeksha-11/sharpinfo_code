package _04_02.before;

@FunctionalInterface
public interface Greeting {

    void printMessage();

}
