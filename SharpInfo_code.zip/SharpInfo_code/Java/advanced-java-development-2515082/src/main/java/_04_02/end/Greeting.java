package _04_02.end;

@FunctionalInterface
public interface Greeting {

    void printMessage();

}
