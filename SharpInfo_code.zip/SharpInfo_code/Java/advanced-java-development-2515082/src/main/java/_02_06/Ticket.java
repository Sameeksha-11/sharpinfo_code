package _02_06;

public abstract class Ticket {
    public abstract int getPrice();

}
