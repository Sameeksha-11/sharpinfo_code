package _07_06.before;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FilesExercise {

    public static void main(String[] args) {
        // Create a new empty file called example.txt inside folderA
        try {
            if(Files.notExists(Paths.get("src/main/java/_07_06/folderA")))
            Files.createDirectory(Paths.get("src/main/java/_07_06/folderA"));
            if(Files.notExists(Paths.get("src/main/java/_07_06/folderB")))
                Files.createDirectory(Paths.get("src/main/java/_07_06/folderB"));

            if(Files.notExists(Paths.get("src/main/java/_07_06/folderA/example.txt")))
            {
                Files.createFile(Paths.get("src/main/java/_07_06/folderA/example.txt"));
            }

            Path pathToCopy = Paths.get("src/main/java/_07_06/folderA/example.txt");
            Path pathToCreate = Paths.get("src/main/java/_07_06/folderB/example.txt");

            if(Files.notExists(pathToCreate))
                Files.copy(pathToCopy, pathToCreate);

            Files.list(Paths.get("src/main/java/_07_06/folderB"))
                    .filter(line -> !Files.isDirectory(line))
                    .forEach(System.out::println);


        }catch (IOException e){e.printStackTrace();}
        // Copy the file to folderB

        // List the contents of folderB to check that your file is in there

    }


}
