package Demo1;

public class GenericFile {
    public void Greetings()
    {
        System.out.println("Good evening");

    }}
