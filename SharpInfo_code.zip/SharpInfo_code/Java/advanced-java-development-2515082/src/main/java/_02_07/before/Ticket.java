package _02_07.before;

public abstract class Ticket {
    public abstract int getPrice();

}
