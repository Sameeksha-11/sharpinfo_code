package _02_07.end;

public abstract class Ticket {
    public abstract int getPrice();

}
