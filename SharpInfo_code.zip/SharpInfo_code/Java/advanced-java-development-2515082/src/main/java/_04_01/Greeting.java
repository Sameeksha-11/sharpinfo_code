package _04_01;

@FunctionalInterface
public interface Greeting {

    void printMessage();

}
