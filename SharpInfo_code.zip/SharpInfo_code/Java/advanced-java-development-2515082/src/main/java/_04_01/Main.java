package _04_01;

public class Main {

    public static void main(String[] args) {
        HelloWorldGreeting helloWorldGreeting = new HelloWorldGreeting();
        helloWorldGreeting.printMessage();
        GoodMorningGreeting goodMorningGreeting = new GoodMorningGreeting();
        goodMorningGreeting.printMessage();
        Greeting helloAfternoon = ()-> System.out.println("Good AfterNoon");
        helloAfternoon.printMessage();
    }

}
