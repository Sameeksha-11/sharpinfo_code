package _07_05;

public class FilesExercise {

    public static void main(String[] args) {
        // Create a new empty file called example.txt inside folderA

        // Copy the file to folderB

        // List the contents of folderB to check that your file is in there

    }


}
