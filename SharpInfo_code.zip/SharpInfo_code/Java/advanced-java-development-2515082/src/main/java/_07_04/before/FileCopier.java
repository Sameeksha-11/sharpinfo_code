package _07_04.before;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileCopier {

    public static void main(String[] args) {
        Path pathToCopy = Paths.get("src/main/java/_07_04/files/a/example.txt");
        Path pathToCreate = Paths.get("src/main/java/_07_04/files/b/example.txt");

        try {

            if(Files.notExists(pathToCreate))
            {
                Files.copy(pathToCopy, pathToCreate);
            }
        }catch (IOException e){e.printStackTrace();}

    }

}
