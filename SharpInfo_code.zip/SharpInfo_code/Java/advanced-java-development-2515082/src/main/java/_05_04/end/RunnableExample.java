package _05_04.end;

public class RunnableExample implements Runnable {

    @Override
    public void run() {
        System.out.println("Hello world from a runnable");
    }
}
