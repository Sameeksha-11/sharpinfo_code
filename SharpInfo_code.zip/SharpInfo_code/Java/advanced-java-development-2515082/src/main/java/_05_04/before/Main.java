package _05_04.before;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {

    public static void main(String[] args) {

       ExecutorService executorService = Executors.newFixedThreadPool(2);
       executorService.submit(new RunnableExample());
       executorService.submit(()-> System.out.println("Thread from executor service"));

       executorService.shutdown();
    }

}
