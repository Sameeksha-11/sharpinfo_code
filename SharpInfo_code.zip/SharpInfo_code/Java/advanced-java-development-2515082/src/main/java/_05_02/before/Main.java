package _05_02.before;

public class Main {

    public static void main(String[] args) {
        Thread T1 = new ThreadExample();
        Thread T2 = new ThreadExample();

//        T1.setName("Thread 1");
//        T2.setName("Thread 2");

        T1.start();
        T2.start();

    }

}
