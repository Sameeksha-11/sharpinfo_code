package _05_02.before;

import javax.sound.midi.Soundbank;
import java.sql.SQLOutput;

public class ThreadExample extends Thread{
    @Override
    public void run()
  {
      System.out.println("This is Thread :"+ this.getName());
  }
}
