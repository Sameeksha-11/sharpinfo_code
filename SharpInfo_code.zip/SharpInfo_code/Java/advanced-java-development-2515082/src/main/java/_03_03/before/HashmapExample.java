package _03_03.before;

import java.util.HashMap;

public class HashmapExample {

    public static void main(String[] args) {
        HashMap<String, Integer> map = new HashMap<>();
        map.put("a1",1);
        map.put("a2",1);
        System.out.println(map);
        map.put("a1",2);
        System.out.println(map);
        map.merge("a1", 1, Integer::sum);
        System.out.println(map);

    }




}
