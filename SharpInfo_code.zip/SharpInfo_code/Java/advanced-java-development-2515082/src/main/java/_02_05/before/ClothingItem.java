package _02_05.before;

public abstract class ClothingItem {

    abstract int getPrice();

    abstract String getName();

}
