package _02_05.end;

public abstract class ClothingItem {

    abstract int getPrice();

    abstract String getName();

}
